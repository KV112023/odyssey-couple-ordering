/* ==================================================================
 * FLUID BACKGROUND — 流体背景
 *
 * 严格移植自 dingyi222666/aura-music v2.0.0 的 packages/background
 * （apps/web-player 的 WebGL2 流体背景）。核心思路：
 *
 *   1. 一张 4×4 的 Hermite 控制网格（位置 + 切向 + 扭曲），
 *      四套 authored 布局（Ribbon / Cove / Diagonal / Fan）用五次缓动轮转；
 *   2. 控制量全部在 GPU 上算：19 次 transform feedback 调用写出
 *      state[38] 这个 std140 uniform block，CPU 不做任何顶点更新；
 *   3. 97×97 的顶点网格在顶点着色器里做张量积 Hermite 插值 + 局部折叠
 *      （tanh 折痕），把一张贴图映射成连续起伏的流体表面；
 *   4. 贴图来自"照片"——先做色调映射，再走 128→64→32→16→32→64→128
 *      的金字塔模糊（Kawase 四对角采样），得到一片只保留空间分布的柔光色场；
 *   5. 片元着色器按曲面 UV 采样这张色场，再叠一层曝光与颗粒。
 *
 * 与 aura-music 的差异（为了独立运行而做的裁剪）：
 *   - 跑在主线程，不进 Web Worker；
 *   - 去掉音频响应（audio envelope 恒为 0），改由一个极缓的"呼吸"项驱动，
 *     让 beat 位移仍然缓慢参与，而不是彻底静止；
 *   - 保留 layouts / tangents / DURATION / crease / Hermite / Kawase 等
 *     全部数值与公式，未做改动。
 * ================================================================== */
(function () {
  'use strict'

  /* ================================================================== *
   * 内核 —— 自包含，序列化后可在 Worker 里执行，也可主线程直接跑。
   * 两条路径共用同一份源码，行为必然一致。
   * ================================================================== */
  function kernelBody(global, IS_WORKER) {
  'use strict'

  /* ---------------------------------------------------------------- *
   * 网格常量（与 aura-music mesh.ts 一致）
   * ---------------------------------------------------------------- */
  const SIZE = 4
  const STEPS = 32
  const SIDE = (SIZE - 1) * STEPS + 1 // 97
  const STRIDE = 8
  const DURATION = 8

  // 四套 4×4 Hermite 布局：外圈固定，内部锚点走宽缎带 / 凹湾 / 对角 / 扇形
  const layouts = [
    [[0.22, 0.29], [0.62, 0.20], [0.39, 0.76], [0.78, 0.63]], // Ribbon
    [[0.36, 0.20], [0.76, 0.39], [0.23, 0.62], [0.61, 0.79]], // Cove
    [[0.23, 0.38], [0.60, 0.25], [0.39, 0.73], [0.77, 0.59]], // Diagonal
    [[0.39, 0.28], [0.75, 0.25], [0.23, 0.70], [0.61, 0.76]], // Fan
  ]

  // 内部切向的方向与长度决定每条缎带的弯折与宽度
  const tangents = [
    [[-0.35, 0.30, 1.20, 0.55], [0.30, -0.40, 0.70, 1.15], [0.40, -0.30, 0.65, 1.10], [-0.30, 0.35, 1.25, 0.60]],
    [[0.30, -0.35, 0.70, 1.20], [-0.40, 0.25, 1.15, 0.60], [-0.25, 0.40, 1.20, 0.65], [0.35, -0.30, 0.60, 1.20]],
    [[-0.30, 0.40, 1.25, 0.65], [0.35, -0.25, 0.65, 1.20], [0.25, -0.35, 0.75, 1.15], [-0.40, 0.30, 1.15, 0.65]],
    [[0.35, -0.30, 0.65, 1.20], [-0.25, 0.35, 1.20, 0.70], [-0.35, 0.25, 1.15, 0.60], [0.30, -0.40, 0.70, 1.25]],
  ]

  const basis = (t) => [
    2 * t * t * t - 3 * t * t + 1,
    -2 * t * t * t + 3 * t * t,
    t * t * t - 2 * t * t + t,
    t * t * t - t * t,
  ]

  /** 不可变的网格拓扑；顶点着色器由 gl_VertexID 推导 UV。 */
  function triangles(side = SIDE) {
    const indices = new Uint16Array((side - 1) * (side - 1) * 6)
    // 相邻的三角形复用刚变换过的顶点（GPU 的小缓存）。
    // 整行推进会在画下一行前把缓存挤掉，所以按 8×8 的瓦片走；
    // 瓦片内从高 u 往低 u 画，让深度测试顺带剔除局部折叠的背面。
    let offset = 0
    for (let right = side - 1; right > 0; right -= 8) {
      for (let top = 0; top < side - 1; top += 8) {
        for (let y = top; y < Math.min(top + 8, side - 1); y++) {
          for (let x = right - 1; x >= Math.max(0, right - 8); x--) {
            const p = y * side + x
            indices.set([p, p + 1, p + side, p + 1, p + side + 1, p + side], offset)
            offset += 6
          }
        }
      }
    }
    return indices
  }

  /** 4×4 网格的调色：把 4 个输入色铺成双线性场。 */
  function palette(input) {
    const colors = (input && input.length)
      ? input
      : [[0.30, 0.16, 0.43], [0.67, 0.31, 0.40], [0.13, 0.25, 0.40], [0.24, 0.15, 0.35]]
    const data = new Float32Array(SIZE * SIZE * 3)
    for (let y = 0; y < SIZE; y++) {
      const v = y / (SIZE - 1)
      for (let x = 0; x < SIZE; x++) {
        const u = x / (SIZE - 1)
        for (let c = 0; c < 3; c++) {
          const top = colors[0][c] * (1 - u) + colors[1 % colors.length][c] * u
          const bottom = colors[2 % colors.length][c] * (1 - u) + colors[3 % colors.length][c] * u
          data[(y * SIZE + x) * 3 + c] = top * (1 - v) + bottom * v
        }
      }
    }
    return data
  }

  /* ---------------------------------------------------------------- *
   * GLSL：Hermite 求值 + 局部折叠（geometry.ts，原样）
   * ---------------------------------------------------------------- */
  const GEOMETRY = `vec4 basis(float t) {
  return vec4(2.0 * t * t * t - 3.0 * t * t + 1.0,
    -2.0 * t * t * t + 3.0 * t * t,
    t * t * t - 2.0 * t * t + t,
    t * t * t - t * t);
}
vec2 surfaceAt(vec2 point) {
  float gx = clamp(point.x * 3.0, 0.0, 3.0);
  float gy = clamp(point.y * 3.0, 0.0, 3.0);
  int cx = min(2, int(floor(gx)));
  int cy = min(2, int(floor(gy)));
  vec4 bx = basis(gx - float(cx));
  vec4 by = basis(gy - float(cy));
  int top = cy * 4 + cx;
  mat4x2 tl = control(top), tr = control(top + 1);
  mat4x2 bl = control(top + 4), br = control(top + 5);
  vec2 a = tl[0] * bx.x + tr[0] * bx.y + tl[1] * bx.z + tr[1] * bx.w;
  vec2 b = bl[0] * bx.x + br[0] * bx.y + bl[1] * bx.z + br[1] * bx.w;
  vec2 c = tl[2] * bx.x + tr[2] * bx.y + tl[3] * bx.z + tr[3] * bx.w;
  vec2 d = bl[2] * bx.x + br[2] * bx.y + bl[3] * bx.z + br[3] * bx.w;
  return a * by.x + b * by.y + c * by.z + d * by.w;
}

vec2 mapPoint(vec2 point) {
  float d = (point.y - foldB.x) / foldB.y;
  float w = max(0.0, 1.0 - d * d);
  float amount = foldA.z * 0.78 * w * w;
  // 静止区域只需要平滑曲面，不必算折叠与 tanh。
  if (amount <= 0.0) {
    vec2 curved = surfaceAt(point);
    return vec2(curved.x * 2.0 - 1.0, 1.0 - curved.y * 2.0);
  }
  float center = foldA.x + foldA.y * (point.y - foldB.x) + foldB.z * d * d;
  float left = amount * tanh(center / foldA.w);
  float right = 1.0 - amount * tanh((1.0 - center) / foldA.w);
  float x = clamp((point.x - amount * tanh((point.x - center) / foldA.w) - left) / (right - left), 0.0, 1.0);
  float weight = min(1.0, amount / foldA.w);
  float blendAmount = weight * weight * (3.0 - 2.0 * weight) * 0.62;
  vec2 curved = surfaceAt(vec2(x, point.y));
  curved = vec2(curved.x * 2.0 - 1.0, 1.0 - curved.y * 2.0);
  vec2 plane = vec2(x * 2.0 - 1.0, 1.0 - point.y * 2.0);
  return curved * (1.0 - blendAmount) + plane * blendAmount;
}
`

  /* ---------------------------------------------------------------- *
   * 网格着色器（webWorkerBackground.worker.ts 的 VERTEX / FRAGMENT）
   * ---------------------------------------------------------------- */
  const MESH_VERTEX = `#version 300 es

out vec2 texcoord;
out vec2 offset;
layout(std140) uniform Controls { vec4 state[38]; };
#define mapping state[34]
uniform float coverage;
out vec3 pigment;
uniform vec3 colors[16];
uniform vec2 aspect;
#define foldA state[32]
#define foldB state[33].xyz
mat4x2 control(int i) {
  return mat4x2(state[i * 2].xy, state[i * 2].zw, state[i * 2 + 1].xy, state[i * 2 + 1].zw);
}
${GEOMETRY}
vec3 colorAt(vec2 point) {
  float gx = clamp(point.x * 3.0, 0.0, 3.0);
  float gy = clamp(point.y * 3.0, 0.0, 3.0);
  int cx = min(2, int(floor(gx)));
  int cy = min(2, int(floor(gy)));
  vec4 bx = basis(gx - float(cx));
  vec4 by = basis(gy - float(cy));
  vec3 result = vec3(0.0);
  for (int j = 0; j < 2; j++) for (int i = 0; i < 2; i++) {
    result += colors[(cy + j) * 4 + cx + i] * bx[i] * by[j];
  }
  return result;
}
float region(vec2 screen, vec2 center, float radius) {
  vec2 d = (screen - center) * state[37].zw / radius;
  float w = max(0.0, 1.0 - dot(d, d));
  return w * w * w;
}
void main() {
  vec2 uv = vec2(gl_VertexID % ${SIDE}, gl_VertexID / ${SIDE}) / ${SIDE - 1}.0;
  // 旋转与漂移由整帧共享，不为每个顶点重算。
  mat2 turn = mat2(mapping.x, -mapping.y, mapping.y, mapping.x);
  texcoord = turn * (uv - vec2(0.23, 0.27)) + 0.5 + mapping.zw;
  pigment = coverage < 1.0 ? colorAt(uv) : vec3(0.0);
  vec2 mapped = mapPoint(uv);
  gl_Position = vec4(mapped * 1.05 * aspect, 0.8 - uv.x * 1.6, 1.0);
  vec2 screen = gl_Position.xy * 0.5 + 0.5;
  float weight = dot(state[35].xy, state[35].xy) > 0.00000001
    ? max(region(screen, state[36].xy, state[37].x), region(screen, state[36].zw, state[37].y) * 0.85)
    : 0.0;
  offset = state[35].xy * weight;
}`

  const MESH_FRAGMENT = `#version 300 es
precision highp float;
in vec2 texcoord;
in vec2 offset;
in vec3 pigment;
out vec4 outputColor;
uniform sampler2D artwork;
uniform sampler2D previous;
uniform float blend;
uniform float coverage;
uniform vec2 resolution;
vec3 cover(vec2 uv) {
  // MIRRORED_REPEAT 在采样器里提供同样的边缘延伸。
  vec3 color = texture(artwork, uv).rgb;
  if (blend < 1.0) color = mix(texture(previous, uv).rgb, color, blend);
  return color;
}
void main() {
  vec3 color = pigment;
  if (coverage > 0.0) {
    vec3 image;
    if (dot(offset, offset) > 0.00000001) {
      image = (cover(texcoord + offset) + cover(texcoord - offset)) * 0.5;
    } else {
      image = cover(texcoord);
    }
    color = mix(pigment, image, coverage);
  }
  // 曝光也放在这次绘制里；最终的放大交给浏览器合成器。
  vec2 uv = gl_FragCoord.xy / resolution;
  float shade = mix(0.58, 0.78, smoothstep(0.0, 1.0, uv.y));
  shade -= 0.045 * smoothstep(0.18, 0.70, length(uv - 0.5));
  float grain = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453) - 0.5;
  outputColor = vec4(color * shade + grain / 255.0, 1.0);
}`

  /* ---------------------------------------------------------------- *
   * 状态着色器（state.ts）——19 次调用写出 608 字节的 uniform block
   * ---------------------------------------------------------------- */
  const vectors = (rows, size) =>
    rows.flatMap((row) => row.map((value) => `vec${size}(${value.map((v) => v.toFixed(8)).join(',')})`)).join(',\n')

  const STATE_VERTEX = `#version 300 es
precision highp float;
precision highp int;
uniform float time;
uniform float audio;
uniform uint seed;
uniform uint episode;
uniform vec2 aspect;
out vec4 first;
out vec4 second;
const vec2 layouts[16] = vec2[16](${vectors(layouts, 2)});
const vec4 tangents[16] = vec4[16](${vectors(tangents, 4)});
int stage;
int next;
float fraction;
vec4 foldA;
vec3 foldB;
float ease(float v) {
  float t = clamp(v, 0.0, 1.0);
  return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);
}
float random(uint n) {
  n = (n ^ 0x9e3779b9u) * 0x21f0aaadu;
  n = (n ^ (n >> 16u)) * 0x735a2d97u;
  return float(n ^ (n >> 15u)) / 4294967296.0;
}
vec2 point(int x, int y) {
  if (x == 0 || y == 0 || x == 3 || y == 3) return vec2(x, y) / 3.0;
  int i = (y - 1) * 2 + x - 1;
  return mix(layouts[stage * 4 + i], layouts[next * 4 + i], fraction);
}
mat2 turn(float angle) {
  float s = sin(angle), c = cos(angle);
  return mat2(c, s, -s, c);
}
mat4x2 control(int i) {
  int x = i % 4, y = i / 4;
  int left = max(0, x - 1), right = min(3, x + 1);
  int top = max(0, y - 1), bottom = min(3, y + 1);
  vec2 du = (point(right, y) - point(left, y)) / float(right - left);
  vec2 dv = (point(x, bottom) - point(x, top)) / float(bottom - top);
  vec2 duv = (point(right, bottom) - point(left, bottom) - point(right, top) + point(left, top)) /
    float((right - left) * (bottom - top));
  if (x > 0 && x < 3 && y > 0 && y < 3) {
    int index = (y - 1) * 2 + x - 1;
    vec4 tangent = mix(tangents[stage * 4 + index], tangents[next * 4 + index], fraction);
    du = turn(tangent.x) * du * tangent.z;
    dv = turn(tangent.y) * dv * tangent.w;
  }
  return mat4x2(point(x, y), du, dv, duv);
}
void crease() {
  float cycle = floor(time / 24.0);
  float phase = time - cycle * 24.0;
  uint key = seed + uint(cycle) * 9u;
  float start = 2.0 + random(key) * 3.0;
  float hold = 4.0 + random(key + 1u) * 4.0;
  float envelope = ease((phase - start) / 2.4) * (1.0 - ease((phase - start - 2.4 - hold) / 3.2));
  float drift = random(key + 2u) * 6.28318530718;
  foldA = vec4(
    0.48 + random(key + 2u) * 0.04 + sin(time * 0.30 + drift) * 0.065 + sin(time * 0.17 + drift) * 0.025,
    (random(key + 3u) - 0.5) * 0.04,
    (0.14 + random(key + 4u) * 0.035) * envelope,
    0.065 + random(key + 5u) * 0.015);
  float cy = 0.47 + random(key + 6u) * 0.06 + sin(time * 0.22 + drift) * 0.07;
  foldB = vec3(0.5 + (cy - 0.5) / aspect.y,
    (0.31 + random(key + 7u) * 0.045) / aspect.y,
    0.055 + random(key + 8u) * 0.03);
}
void main() {
  float phase = mod(time / ${DURATION.toFixed(1)}, 4.0);
  stage = int(floor(phase));
  next = (stage + 1) % 4;
  fraction = ease(fract(phase));
  int i = gl_VertexID;
  if (i < 16) {
    mat4x2 data = control(i);
    first = vec4(data[0], data[1]);
    second = vec4(data[2], data[3]);
  } else if (i == 17) {
    float angle = 0.55 + time * 0.14;
    first = vec4(cos(angle), sin(angle), sin(time * 0.071) * 0.07, cos(time * 0.093) * 0.07);
    second = vec4(turn(-time * 0.11) * vec2(0.29, 0.16) * audio, 0.0, 0.0);
  } else if (i == 16) {
    crease();
    first = foldA;
    second = vec4(foldB, 0.0);
  } else {
    uint key = seed + episode * 23u;
    int a = min(3, int(random(key + 15u) * 4.0));
    int b = (a + 1 + min(2, int(random(key + 16u) * 3.0))) % 4;
    first = vec4(float(a & 1), float(a >> 1), float(b & 1), float(b >> 1));
    second = vec4(0.68, 0.62, aspect.yx);
  }
  gl_Position = vec4(0.0);
}`

  /* ---------------------------------------------------------------- *
   * 照片预处理（artwork.ts）——色调映射 + Kawase 金字塔模糊
   * ---------------------------------------------------------------- */
  const ART_VERTEX = `#version 300 es
out vec2 uv;
void main() {
  vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  uv = p;
  gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}`

  const ART_FRAGMENT = `#version 300 es
precision highp float;
in vec2 uv;
uniform sampler2D image;
uniform sampler2D previous;
uniform vec2 texel;
uniform int mode;
uniform float blend;
out vec4 color;
vec3 sampleAt(vec2 p) {
  // 镜像延伸避免出现暗边或重复的边缘条纹。
  return texture(image, 1.0 - abs(mod(p, 2.0) - 1.0)).rgb;
}
void main() {
  if (mode == 0) {
    vec4 pixel = texture(image, uv);
    float luma = dot(pixel.rgb, vec3(.30, .59, .11));
    float tone = luma * .72 + .14;
    vec3 delta = pixel.rgb - luma;
    float gain = 1.9;
    for (int i = 0; i < 3; i++) {
      if (delta[i] > 0.0) gain = min(gain, (1.0 - tone) / delta[i]);
      if (delta[i] < 0.0) gain = min(gain, -tone / delta[i]);
    }
    color = vec4((tone + delta * gain) * pixel.a, 1.0);
    return;
  }
  if (mode == 3) {
    color = vec4(mix(texture(previous, uv).rgb, texture(image, uv).rgb, blend), 1.0);
    return;
  }
  if (mode == 1) {
    vec3 sum = sampleAt(uv) * 4.0;
    sum += sampleAt(uv + texel) + sampleAt(uv - texel);
    sum += sampleAt(uv + vec2(texel.x, -texel.y)) + sampleAt(uv + vec2(-texel.x, texel.y));
    color = vec4(sum / 8.0, 1.0);
    return;
  }
  vec3 sum = sampleAt(uv + vec2(texel.x, 0.0)) + sampleAt(uv - vec2(texel.x, 0.0));
  sum += sampleAt(uv + vec2(0.0, texel.y)) + sampleAt(uv - vec2(0.0, texel.y));
  sum += 2.0 * (sampleAt(uv + texel * .5) + sampleAt(uv - texel * .5));
  sum += 2.0 * (sampleAt(uv + vec2(texel.x, -texel.y) * .5) + sampleAt(uv + vec2(-texel.x, texel.y) * .5));
  color = vec4(sum / 12.0, 1.0);
}`

  /* ---------------------------------------------------------------- *
   * 小型 GL 工具
   * ---------------------------------------------------------------- */
  function compile(gl, kind, source, label) {
    const shader = gl.createShader(kind)
    gl.shaderSource(shader, source)
    gl.compileShader(shader)
    if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
      const log = gl.getShaderInfoLog(shader)
      gl.deleteShader(shader)
      throw new Error(label + ': ' + log)
    }
    return shader
  }

  function program(gl, vs, fs, label) {
    const p = gl.createProgram()
    const v = compile(gl, gl.VERTEX_SHADER, vs, label + ' vertex')
    const f = compile(gl, gl.FRAGMENT_SHADER, fs, label + ' fragment')
    gl.attachShader(p, v)
    gl.attachShader(p, f)
    gl.linkProgram(p)
    gl.deleteShader(v)
    gl.deleteShader(f)
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) {
      throw new Error(label + ' link: ' + gl.getProgramInfoLog(p))
    }
    return p
  }

  /* ================================================================ *
   * Artwork —— 照片的 GPU 预处理，动画循环里没有任何回读或模糊开销
   * ================================================================ */
  function Artwork(gl) {
    const self = {}
    const prog = program(gl, ART_VERTEX, ART_FRAGMENT, 'Artwork')
    const vao = gl.createVertexArray()
    const fbo = gl.createFramebuffer()
    let source = null
    const targets = new Map()
    const canvas = document.createElement('canvas')
    canvas.width = canvas.height = 128
    const ctx = canvas.getContext('2d', { willReadFrequently: true })

    gl.useProgram(prog)
    gl.uniform1i(gl.getUniformLocation(prog, 'image'), 0)
    gl.uniform1i(gl.getUniformLocation(prog, 'previous'), 1)
    const uMode = gl.getUniformLocation(prog, 'mode')
    const uTexel = gl.getUniformLocation(prog, 'texel')
    const uBlend = gl.getUniformLocation(prog, 'blend')

    function makeTexture(size, mirror) {
      const t = gl.createTexture()
      gl.bindTexture(gl.TEXTURE_2D, t)
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, size, size, 0, gl.RGBA, gl.UNSIGNED_BYTE, null)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, mirror ? gl.MIRRORED_REPEAT : gl.CLAMP_TO_EDGE)
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, mirror ? gl.MIRRORED_REPEAT : gl.CLAMP_TO_EDGE)
      return t
    }

    function draw(src, dst, width, size, mode) {
      gl.useProgram(prog)
      gl.bindVertexArray(vao)
      gl.disable(gl.DEPTH_TEST)
      gl.bindFramebuffer(gl.FRAMEBUFFER, fbo)
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, dst, 0)
      gl.activeTexture(gl.TEXTURE0)
      gl.bindTexture(gl.TEXTURE_2D, src)
      gl.uniform1i(uMode, mode)
      gl.uniform2f(uTexel, 1.3 / width, 1.3 / width)
      gl.viewport(0, 0, size, size)
      gl.drawArrays(gl.TRIANGLES, 0, 3)
    }

    /**
     * 按 cover 方式把图铺满 128×128。
     * 原来直接 drawImage(bitmap, 0, 0, 128, 128) 是拉伸：任何非正方形的
     * 照片都会被压扁（横拍的变矮胖，竖拍的变窄长）。
     */
    function drawCover(bmp, size) {
      const iw = bmp.width || bmp.naturalWidth || 1
      const ih = bmp.height || bmp.naturalHeight || 1
      const scale = Math.max(size / iw, size / ih)
      const dw = iw * scale
      const dh = ih * scale
      ctx.drawImage(bmp, (size - dw) / 2, (size - dh) / 2, dw, dh)
    }

    /** 传入任意图源（Image / canvas / ImageBitmap），返回可用的柔光贴图。 */
    self.prepare = function (bitmap) {
      gl.activeTexture(gl.TEXTURE0)
      if (!source) {
        source = makeTexture(128, false)
        for (const size of [128, 64, 32, 16]) targets.set(size, makeTexture(size, false))
      }
      canvas.width = canvas.height = 128
      ctx.clearRect(0, 0, 128, 128)
      drawCover(bitmap, 128)
      gl.bindTexture(gl.TEXTURE_2D, source)
      gl.texSubImage2D(gl.TEXTURE_2D, 0, 0, 0, gl.RGBA, gl.UNSIGNED_BYTE, canvas)
      // 只有最终那张需要新分配，金字塔的各级目标都复用。
      const result = makeTexture(128, true)
      let src = source
      let width = 128
      // 上行时复用降采样目标：每个前值在被重新作为输出前已被消费完。
      for (const size of [128, 64, 32, 16, 32, 64]) {
        const dst = targets.get(size)
        draw(src, dst, width, size, src === source ? 0 : (size < width ? 1 : 2))
        src = dst
        width = size
      }
      draw(src, result, width, 128, 2)
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, null, 0)
      return result
    }

    self.mix = function (prev, cur, amount) {
      gl.activeTexture(gl.TEXTURE0)
      const result = makeTexture(128, true)
      gl.useProgram(prog)
      gl.activeTexture(gl.TEXTURE1)
      gl.bindTexture(gl.TEXTURE_2D, prev)
      gl.uniform1f(uBlend, amount)
      draw(cur, result, 128, 128, 3)
      gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, null, 0)
      return result
    }

    /** 从一张图提取 4 个主色（2×2 分区平均）。 */
    self.colors = function (bitmap) {
      canvas.width = canvas.height = 128
      ctx.clearRect(0, 0, 128, 128)
      // 必须和 prepare 用同一种裁剪，否则主色取自"被裁掉"的区域，
      // 和画面上看到的对不上。
      drawCover(bitmap, 128)
      const data = ctx.getImageData(0, 0, 128, 128).data
      const out = []
      for (let qy = 0; qy < 2; qy++) {
        for (let qx = 0; qx < 2; qx++) {
          let r = 0, g = 0, b = 0, n = 0
          for (let y = qy * 64; y < qy * 64 + 64; y += 4) {
            for (let x = qx * 64; x < qx * 64 + 64; x += 4) {
              const i = (y * 128 + x) * 4
              r += data[i]; g += data[i + 1]; b += data[i + 2]; n++
            }
          }
          out.push([r / n / 255, g / n / 255, b / n / 255])
        }
      }
      return out
    }

    self.dispose = function () {
      if (source) gl.deleteTexture(source)
      for (const t of targets.values()) gl.deleteTexture(t)
      targets.clear()
      gl.deleteProgram(prog)
      gl.deleteVertexArray(vao)
      gl.deleteFramebuffer(fbo)
    }
    return self
  }

  /* ================================================================ *
   * State —— transform feedback 写出 state[38]，驱动整个曲面
   * ================================================================ */
  function State(gl, seed) {
    const self = {}
    const prog = gl.createProgram()
    const vs = compile(gl, gl.VERTEX_SHADER, STATE_VERTEX, 'Background state')
    const fs = compile(gl, gl.FRAGMENT_SHADER, '#version 300 es\nprecision highp float;\nvoid main() {}', 'state stub')
    gl.attachShader(prog, vs)
    gl.attachShader(prog, fs)
    gl.transformFeedbackVaryings(prog, ['first', 'second'], gl.INTERLEAVED_ATTRIBS)
    gl.linkProgram(prog)
    gl.deleteShader(vs)
    gl.deleteShader(fs)
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
      throw new Error('State link: ' + gl.getProgramInfoLog(prog))
    }
    const buffer = gl.createBuffer()
    const feedback = gl.createTransformFeedback()
    const vao = gl.createVertexArray()
    gl.bindBuffer(gl.TRANSFORM_FEEDBACK_BUFFER, buffer)
    gl.bufferData(gl.TRANSFORM_FEEDBACK_BUFFER, 19 * 8 * 4, gl.DYNAMIC_COPY)
    gl.bindBuffer(gl.TRANSFORM_FEEDBACK_BUFFER, null)
    gl.useProgram(prog)
    gl.uniform1ui(gl.getUniformLocation(prog, 'seed'), seed)
    const uTime = gl.getUniformLocation(prog, 'time')
    const uAudio = gl.getUniformLocation(prog, 'audio')
    const uAspect = gl.getUniformLocation(prog, 'aspect')
    const uEpisode = gl.getUniformLocation(prog, 'episode')

    let lastTime = NaN, lastPulse = NaN, lastRatio = NaN, lastEpisode = -1

    self.draw = function (time, pulse, ratio, episode) {
      if (time === lastTime && pulse === lastPulse && ratio === lastRatio && episode === lastEpisode) return
      lastTime = time; lastPulse = pulse; lastRatio = ratio; lastEpisode = episode
      gl.bindBufferBase(gl.UNIFORM_BUFFER, 0, null)
      gl.bindFramebuffer(gl.FRAMEBUFFER, null)
      gl.useProgram(prog)
      gl.bindVertexArray(vao)
      gl.uniform1f(uTime, time)
      gl.uniform1f(uAudio, pulse)
      gl.uniform1ui(uEpisode, episode)
      gl.uniform2f(uAspect, Math.max(1, 1 / ratio), Math.max(1, ratio))
      gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK, feedback)
      gl.bindBufferBase(gl.TRANSFORM_FEEDBACK_BUFFER, 0, buffer)
      gl.enable(gl.RASTERIZER_DISCARD)
      gl.beginTransformFeedback(gl.POINTS)
      gl.drawArrays(gl.POINTS, 0, 19)
      gl.endTransformFeedback()
      gl.disable(gl.RASTERIZER_DISCARD)
      gl.bindBufferBase(gl.TRANSFORM_FEEDBACK_BUFFER, 0, null)
      gl.bindTransformFeedback(gl.TRANSFORM_FEEDBACK, null)
      gl.bindBufferBase(gl.UNIFORM_BUFFER, 0, buffer)
    }

    self.dispose = function () {
      gl.bindBufferBase(gl.UNIFORM_BUFFER, 0, null)
      gl.deleteTransformFeedback(feedback)
      gl.deleteBuffer(buffer)
      gl.deleteVertexArray(vao)
      gl.deleteProgram(prog)
    }
    return self
  }

  /* ================================================================ *
   * FluidBackground —— 对外接口
   * ================================================================ */
  function FluidBackground(canvas, options) {
    const opts = options || {}
    // Worker 里没有 DOM canvas，自己造一块 —— 背景本来就是给玻璃渲染器
    // 当纹理用的，不需要挂进文档。
    if (!canvas) {
      if (typeof OffscreenCanvas !== 'function') throw new Error('no canvas available')
      canvas = new OffscreenCanvas(Math.max(1, opts.width || 1), Math.max(1, opts.height || 1))
    }
    const gl = canvas.getContext('webgl2', {
      alpha: false, antialias: false, depth: true, stencil: false,
      powerPreference: 'low-power',
      // 关键：这个 canvas 会被当作纹理上传给玻璃渲染器。默认 false 时
      // 浏览器合成后 drawing buffer 立刻被清空，外面再 texImage2D 读它
      // 只会拿到一张全黑纹理（背景死黑的根源）。
      preserveDrawingBuffer: true,
    })
    if (!gl) throw new Error('WebGL2 unavailable for fluid background')

    const topology = triangles()
    const seed = Math.floor(Math.random() * 0x7fffffff)

    const meshProg = program(gl, MESH_VERTEX, MESH_FRAGMENT, 'Mesh')
    const artwork = Artwork(gl)
    const state = State(gl, seed)

    const vao = gl.createVertexArray()
    gl.bindVertexArray(vao)
    const indices = gl.createBuffer()
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indices)
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, topology, gl.STATIC_DRAW)
    gl.bindVertexArray(null)

    gl.useProgram(meshProg)
    gl.uniformBlockBinding(meshProg, gl.getUniformBlockIndex(meshProg, 'Controls'), 0)
    gl.uniform1i(gl.getUniformLocation(meshProg, 'artwork'), 0)
    gl.uniform1i(gl.getUniformLocation(meshProg, 'previous'), 1)
    const uColors = gl.getUniformLocation(meshProg, 'colors[0]')
    const uAspect = gl.getUniformLocation(meshProg, 'aspect')
    const uResolution = gl.getUniformLocation(meshProg, 'resolution')
    const uBlend = gl.getUniformLocation(meshProg, 'blend')
    const uCoverage = gl.getUniformLocation(meshProg, 'coverage')

    // 1×1 的占位贴图，避免没有照片时采样到未定义纹理
    const fallback = gl.createTexture()
    gl.bindTexture(gl.TEXTURE_2D, fallback)
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE,
      new Uint8Array([40, 32, 28, 255]))
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.MIRRORED_REPEAT)
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.MIRRORED_REPEAT)

    let texture = null       // 当前照片贴图
    let previous = null      // 换图交叉淡入用的旧图
    let covered = false
    /* 过渡用「线性 raw 进度 + 非线性输出」两级表示。
     * 原来直接 `transition += dt / 1.2` 是纯线性，起停都有明显台阶感。
     * raw 只负责按时间推进（顺带当作"是否已到位"的判据），
     * 真正送进 shader 的是 smoothstep(raw) —— 两端都缓。 */
    let coverageRaw = 0
    let fadeRaw = 1
    let transitionRaw = 1
    let coverage = 0
    let fade = 1
    let transition = 1

    /** 两端都缓的 S 曲线。 */
    function smoothstep(t) {
      t = t < 0 ? 0 : t > 1 ? 1 : t
      return t * t * (3 - 2 * t)
    }

    gl.clearColor(0.012, 0.02, 0.043, 1)

    let width = 1, height = 1
    let elapsed = 0
    let last = 0
    let dirty = true
    let running = false
    let raf = 0
    let paused = false

    let target = palette([])
    let origin = target.slice()
    const colors = target.slice()

    /* -------------------------------------------------------------- *
     * 帧率预算 + 分辨率收缩
     *
     * 用 GPU timer 采样真实绘制耗时，连续超预算就降一档分辨率；
     * fenceSync 限流防止 CPU 一直往前排队。
     * -------------------------------------------------------------- */
    // 满档细节栅格。原来 768，但壁纸最终会被降采样到 384~512 长边再
    // 交给玻璃模糊 —— 渲染到 768 再缩下来是纯浪费。576 略高于最大上传
    // 尺寸，留一点放大余量，像素数比 768 少 44%。
    const BASE = 576
    const SCALES = [1.0, 0.75, 0.56, 0.42]
    const BUDGET_MS = 7
    const BUDGET_STREAK = 4
    const IDLE_RECOVER_MS = 20000
    const MAX_PENDING = 3

    const COLLECT_EVERY = 8
    const timerExt = gl.getExtension('EXT_disjoint_timer_query_webgl2')
    let frameCount = 0
    let scaleIndex = 0
    let overStreak = 0
    let lastOver = 0
    const pending = []
    let gpuMs = -1

    function applyScale() {
      if (width > 1) resize(width, height)
    }

    function budgetBegin() {
      if (!timerExt || pending.length >= MAX_PENDING) return null
      let q = null
      try { q = gl.createQuery() } catch (e) { return null }
      if (!q) return null
      try { gl.beginQuery(timerExt.TIME_ELAPSED_EXT, q) } catch (e) { return null }
      return q
    }

    function budgetEnd(q) {
      if (!q) return
      try { gl.endQuery(timerExt.TIME_ELAPSED_EXT) } catch (e) { return }
      pending.push(q)
    }

    /** 回收完成的 query：连续超预算降档，空闲久了逐档回升。 */
    function budgetCollect(now) {
      if (!timerExt) return
      while (pending.length) {
        const q = pending[0]
        let ready = false
        try { ready = gl.getQueryParameter(q, gl.QUERY_RESULT_AVAILABLE) } catch (e) { ready = false }
        if (!ready) break
        try {
          // disjoint = 这次计时被 GPU 打断，数据不可信，直接丢
          if (!gl.getParameter(timerExt.GPU_DISJOINT_EXT)) {
            const ms = gl.getQueryParameter(q, gl.QUERY_RESULT) / 1e6
            gpuMs = Math.round(ms * 100) / 100
            if (ms > BUDGET_MS) {
              overStreak++
              lastOver = now
              if (overStreak >= BUDGET_STREAK && scaleIndex < SCALES.length - 1) {
                scaleIndex++
                overStreak = 0
                applyScale()
              }
            } else {
              overStreak = 0
            }
          }
        } catch (e) {}
        try { gl.deleteQuery(q) } catch (e) {}
        pending.shift()
      }
      // 一次只回升一档，避免刚升上去又超预算来回抖
      if (scaleIndex > 0 && now - lastOver > IDLE_RECOVER_MS) {
        scaleIndex--
        lastOver = now
        applyScale()
      }
    }

    function resize(w, h) {
      width = Math.max(1, w)
      height = Math.max(1, h)
      // 曲面按 BASE*scale 的细节栅格化，剩下的放大交给浏览器合成
      const ratio = Math.min(1, (BASE * SCALES[scaleIndex]) / Math.max(width, height))
      const x = Math.max(1, Math.round(width * ratio))
      const y = Math.max(1, Math.round(height * ratio))
      if (canvas.width !== x) canvas.width = x
      if (canvas.height !== y) canvas.height = y
      dirty = true
      gl.useProgram(meshProg)
      gl.uniform2f(uAspect, Math.max(1, height / width), Math.max(1, width / height))
      gl.uniform2f(uResolution, x, y)
    }

    function change(next, immediate) {
      origin = colors.slice()
      target = next
      transitionRaw = immediate ? 1 : 0
      transition = immediate ? 1 : 0
      if (immediate) colors.set(next)
    }

    function render(now) {
      const dt = Math.max(0, Math.min(0.05, (now - last) / 1000))
      last = now
      if (!paused) {
        // 与 aura-music 一致：流动时钟 *0.4
        elapsed += dt * 0.4
        transitionRaw = Math.min(1, transitionRaw + dt / 1.2)
        fadeRaw = Math.min(1, fadeRaw + dt / 1.2)
        coverageRaw = covered
          ? Math.min(1, coverageRaw + dt / 0.8)
          : Math.max(0, coverageRaw - dt / 0.8)
      }
      // 非线性输出：两端都缓，换图 / 换色没有突兀的起停
      transition = smoothstep(transitionRaw)
      fade = smoothstep(fadeRaw)
      coverage = smoothstep(coverageRaw)
      // 回收 query 会同步问 GPU "好了没"，每帧都问等于每帧插一个同步点，
      // 把 CPU/GPU 的流水线打断。改成每 COLLECT_EVERY 帧收一次，
      // query 会攒着，一次回收多个。
      if ((frameCount++ % COLLECT_EVERY) === 0) budgetCollect(now)
      const q = budgetBegin()

      const blend = transition * transition * (3 - 2 * transition)
      for (let i = 0; i < colors.length; i++) colors[i] = origin[i] + (target[i] - origin[i]) * blend

      // 没有音频，用一个极缓的"呼吸"驱动 beat 位移（0.06 幅度，周期约 20s）
      const pulse = 0.06 * (0.5 + 0.5 * Math.sin(elapsed * 0.31))
      state.draw(elapsed, pulse, width / height, 0)

      gl.useProgram(meshProg)
      gl.bindFramebuffer(gl.FRAMEBUFFER, null)
      gl.viewport(0, 0, canvas.width, canvas.height)
      gl.enable(gl.DEPTH_TEST)
      gl.depthFunc(gl.LESS)
      gl.bindVertexArray(vao)
      gl.uniform3fv(uColors, colors)
      gl.uniform1f(uBlend, fade * fade * (3 - 2 * fade))
      gl.uniform1f(uCoverage, coverage)
      gl.activeTexture(gl.TEXTURE0)
      gl.bindTexture(gl.TEXTURE_2D, texture || fallback)
      gl.activeTexture(gl.TEXTURE1)
      gl.bindTexture(gl.TEXTURE_2D, previous || texture || fallback)
      gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT)
      gl.drawElements(gl.TRIANGLES, topology.length, gl.UNSIGNED_SHORT, 0)
      gl.bindVertexArray(null)

      budgetEnd(q)

      // 关于限流：原来这里每帧 fenceSync + clientWaitSync(sync, 0, 0)，
      // 但 clientWaitSync 的第三个参数是 timeout，传 0 表示**根本不等待**、
      // 立即返回。也就是说它没有起到任何背压作用，却每帧都要创建并删除
      // 一个 sync 对象 —— 是纯开销。
      // WebGL 本身有浏览器层面的命令背压，不需要应用层再补一道。
      // 真要限流，只在 timer query 堆积到上限时才短暂等待一次。
      if (pending.length >= MAX_PENDING && gl.fenceSync) {
        try {
          const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0)
          if (sync) {
            gl.clientWaitSync(sync, 0, 250000)   // 0.25ms，够触发背压又不卡帧
            gl.deleteSync(sync)
          }
        } catch (e) {}
      }

      // 用 raw 判断：eased 值会提前逼近 1 / 0，拿它删纹理会删早了
      if (fadeRaw >= 1 && previous) {
        gl.deleteTexture(previous)
        previous = null
      }
      if (!covered && coverageRaw === 0 && texture) {
        gl.deleteTexture(texture)
        texture = null
      }
      dirty = false
    }

    // 目标帧率。背景是缓慢流动的柔光曲面，不需要 60fps；
    // 而 Worker 跑满 rAF 时，多渲染出来的一半帧主线程根本来不及消费，
    // 白烧 GPU（手机上直接体现为发热和掉帧）。
    const TARGET_FPS = opts.targetFps || 30
    const frameBudget = 1000 / TARGET_FPS
    let lastDraw = 0

    function loop(now) {
      if (!running) return
      // 时间累加而不是"跳帧计数"：rAF 本身的间隔会漂，
      // 按累计时间判定才不会把实际帧率跑偏。
      if (now - lastDraw >= frameBudget - 1) {
        lastDraw = now
        render(now)
      }
      raf = requestAnimationFrame(loop)
    }

    const api = {
      canvas: canvas,
      lastError: null,
      resize: resize,
      start: function () {
        if (running) return
        running = true
        last = performance.now()
        lastDraw = 0
        raf = requestAnimationFrame(loop)
      },
      stop: function () {
        running = false
        if (raf) cancelAnimationFrame(raf)
        raf = 0
      },
      setPaused: function (v) { paused = !!v },
      /** 渲染一帧并画到自己的 canvas 上（供外部取像素 / 截图）。 */
      renderOnce: function () { render(performance.now()) },
      /** 当前分辨率档位与最近一次 GPU 耗时，供诊断用。 */
      budget: function () {
        return { scale: SCALES[scaleIndex], gpuMs: gpuMs, timer: !!timerExt }
      },
      /** 内部状态快照，供诊断。 */
      status: function () {
        return {
          coverage: coverage, fade: fade, transition: transition,
          covered: covered, hasTexture: !!texture,
          size: [canvas.width, canvas.height],
          scale: SCALES[scaleIndex], gpuMs: gpuMs, timer: !!timerExt,
        }
      },

      /**
       * 用固定步长同步把过渡跑完，不依赖 rAF。
       *
       * coverage 需要 0.8s、fade 需要 1.2s 才能到位，而这两者只在 rAF
       * 回调里推进。挑照片时页面常被节流、被判定为隐藏，或 rAF 干脆停掉
       * —— 于是 coverage/fade 永远停在 0，照片根本混不进来，观感就是
       * "放了照片但背景没反应 / 不动了"。这里是这个坑的根治：不管 rAF
       * 在不在跑，都把过渡推到位。
       */
      settle: function (ms) {
        const steps = Math.max(1, Math.ceil((ms || 1400) / 50))
        const wasPaused = paused
        paused = false
        let t = performance.now()
        last = t - 50            // 让第一帧就拿到满步长（dt 上限 0.05s）
        for (let i = 0; i < steps; i++) {
          t += 50
          render(t)
        }
        paused = wasPaused
        last = performance.now()  // 别把 last 留在未来，否则下一帧 dt=0
        dirty = true
      },

      /** 只看过渡状态，不读像素 —— 供高频轮询用。 */
      converge: function () {
        // 返回 raw：它是"是否已到位"的真实判据。
        // eased 值在末端会提前逼近 1，拿它判断会误判完成。
        return {
          coverage: coverageRaw,
          fade: fadeRaw,
          transition: transitionRaw,
          covered: covered,
        }
      },

      /** 内部状态快照，用于排查"背景没反应"这类问题。 */
      diagnose: function () {
        let luma = -1
        try { luma = api.sampleLuma() } catch (e) { luma = -1 }
        return {
          luma: Math.round(luma * 10) / 10,
          coverage: Math.round(coverage * 1000) / 1000,
          fade: Math.round(fade * 1000) / 1000,
          covered: covered,
          hasTexture: !!texture,
          size: [canvas.width, canvas.height],
          paused: paused,
          running: running,
          error: api.lastError || null,
        }
      },
      /**
       * 自检：渲染一帧后回读中心区域，返回平均通道亮度（0~255）。
       * 低于阈值说明这条管线在当前设备上画不出东西（驱动 / 扩展问题），
       * 调用方应据此降级到别的背景方案，而不是留一块黑屏。
       */
      /**
       * 自检：喂一张纯白测试图，推进到稳定态后回读像素，返回最亮区块的
       * 平均通道值（0~255）。
       *
       * 这里必须用白图 + 高阈值。用真实照片测会漏判：清屏色本身就有
       * (3,5,11) ≈ 6.3 的亮度，而暗色壁纸渲染完也可能只有十几 —— 只要
       * 阈值低于清屏色，即便着色器完全没画出网格（画面只剩清屏色），
       * 自检也会误判成"可用"，于是页面就留下一片死黑。
       *
       * 白图在管线正常时输出约 130~180，失败时只剩清屏色 6.3，
       * 两者差一个数量级，阈值取 25 可以干净地区分开。
       */
      /** 回读当前画面，返回最亮区块的平均通道值（0~255）。不动状态。 */
      sampleLuma: function () {
        const n = 8
        const px = new Uint8Array(4 * n * n)
        let best = 0
        for (const fy of [0.5, 0.32, 0.68]) {
          gl.bindFramebuffer(gl.FRAMEBUFFER, null)
          gl.readPixels(
            Math.max(0, Math.min(canvas.width - n, Math.floor(canvas.width / 2) - n / 2)),
            Math.max(0, Math.min(canvas.height - n, Math.floor(canvas.height * fy) - n / 2)),
            n, n, gl.RGBA, gl.UNSIGNED_BYTE, px)
          let sum = 0
          for (let i = 0; i < px.length; i += 4) sum += px[i] + px[i + 1] + px[i + 2]
          best = Math.max(best, sum / (n * n * 3))
        }
        return best
      },

      probe: function () {
        try {
          const white = document.createElement('canvas')
          white.width = white.height = 128
          const wc = white.getContext('2d')
          wc.fillStyle = '#ffffff'
          wc.fillRect(0, 0, 128, 128)

          // 记住当前照片，测完放回
          const savedPhoto = api.currentPhoto
          api.setPhoto(white)
          // 推进到稳定态：coverage 满需要 0.8s，fade 满需要 1.2s
          const t0 = performance.now()
          for (let i = 0; i < 100; i++) render(t0 + i * 16)

          const best = api.sampleLuma()

          // 复原：把真实照片放回去，并让过渡从头开始
          if (savedPhoto) {
            api.setPhoto(savedPhoto)
          } else {
            covered = false
          }
          fade = 0
          coverage = 0
          dirty = true
          return best
        } catch (e) {
          return -1
        }
      },
      /** 设置照片：Image / canvas / ImageBitmap 都行，null 表示退回纯色场。 */
      setPhoto: function (bitmap) {
        api.currentPhoto = bitmap || null
        if (!bitmap) {
          covered = false
          dirty = true
          return
        }
        let next = null
        try {
          next = artwork.prepare(bitmap)
        } catch (e) {
          api.lastError = 'artwork prepare: ' + ((e && e.message) || e)
        }
        // 上传失败就保留现有贴图直接返回：半坏状态会让画面糊掉或变黑，
        // 宁可什么都不做。
        if (!next) { dirty = true; return }
        try {
          change(palette(artwork.colors(bitmap)))
        } catch (e) {
          api.lastError = 'palette: ' + ((e && e.message) || e)
        }
        api.lastError = null
        // 换图时把当前画面作为起点，交叉淡入到新图
        if (covered && fade < 1 && previous && texture) {
          const amount = fade * fade * (3 - 2 * fade)
          const current = artwork.mix(previous, texture, amount)
          gl.deleteTexture(previous)
          previous = current
        } else if (texture && covered) {
          if (previous) gl.deleteTexture(previous)
          previous = texture
        } else if (texture) {
          gl.deleteTexture(texture)
        }
        texture = next
        covered = true
        fadeRaw = 0
        fade = 0
        dirty = true
      },
      /** 只换配色，不动贴图。 */
      setColors: function (list) { change(palette(list)) },
      dispose: function () {
        api.stop()
        artwork.dispose()
        state.dispose()
        gl.deleteVertexArray(vao)
        gl.deleteBuffer(indices)
        gl.deleteProgram(meshProg)
        gl.deleteTexture(fallback)
        gl.deleteTexture(texture)
        gl.deleteTexture(previous)
      },
    }

    resize(opts.width || 1, opts.height || 1)
    return api
  }

  FluidBackground.supported = (function () {
    try {
      const c = (typeof OffscreenCanvas === 'function')
        ? new OffscreenCanvas(1, 1)
        : (typeof document !== 'undefined' ? document.createElement('canvas') : null)
      return !!c && !!c.getContext('webgl2')
    } catch (e) { return false }
  })()

  global.FluidBackground = FluidBackground
  global.__fluidKernel = { FluidBackground: FluidBackground, palette: palette }

  /* ------------------------------------------------------------------ *
   * Worker 侧 glue：只有真正跑在 Worker 里才会装上
   * ------------------------------------------------------------------ */
  if (IS_WORKER) installWorkerGlue(global)

  function installWorkerGlue(scope) {
    let kernel = null
    let lastReport = 0

    scope.onmessage = function (e) {
      const m = e.data
      if (!m) return
      try {
        if (m.type === 'attach') {
          kernel = FluidBackground(m.canvas, {
            width: m.width, height: m.height, seed: m.seed,
          })
          scope.postMessage({ type: 'ready' })
          // 背景不直接显示，由主线程定期拉取；这里自己起帧循环
          kernel.start()
          return
        }
        if (!kernel) return
        if (m.type === 'resize') kernel.resize(m.width, m.height)
        else if (m.type === 'start') kernel.start()
        else if (m.type === 'stop') kernel.stop()
        else if (m.type === 'paused') kernel.setPaused(m.value)
        else if (m.type === 'colors') kernel.setColors(m.colors)
        else if (m.type === 'photo') kernel.setPhoto(m.bitmap)
        else if (m.type === 'renderOnce') kernel.renderOnce()
        else if (m.type === 'settle') kernel.settle(m.ms)
        else if (m.type === 'report') kernel.report()
        else if (m.type === 'frame') emitFrame()
      } catch (err) {
        scope.postMessage({ type: 'error', message: (err && err.message) || String(err) })
      }
    }

    /**
     * 回传一帧给主线程。
     * 用 transferToImageBitmap 而不是让主线程直接读 canvas ——
     * 画布控制在 Worker 手里，主线程 texImage2D 读它是未定义行为。
     * ImageBitmap 是规范的 TexImageSource，transfer 还是零拷贝。
     */
    function emitFrame() {
      if (!kernel) return
      const cv = kernel.canvas
      if (!cv || typeof cv.transferToImageBitmap !== 'function') return
      let bmp = null
      try { bmp = cv.transferToImageBitmap() } catch (e) { return }
      if (!bmp) return
      let luma = -1
      try { luma = kernel.sampleLuma() } catch (e) {}
      const now = (typeof performance !== 'undefined' ? performance.now() : Date.now())
      // 状态顺带捎回去，省一次消息
      const c = kernel.converge()
      const b = kernel.budget ? kernel.budget() : {}
      const payload = {
        type: 'frame', bitmap: bmp, luma: luma,
        coverage: c.coverage, fade: c.fade, transition: c.transition, covered: c.covered,
        size: [cv.width, cv.height],
        scale: b.scale, gpuMs: b.gpuMs, timer: b.timer,
      }
      lastReport = now
      try {
        scope.postMessage(payload, [bmp])
      } catch (e) {
        // transfer 失败就退化成结构化克隆（慢，但不会丢帧）
        try { scope.postMessage(payload) } catch (e2) {}
      }
    }
  }
  }

  /* ================================================================== *
   * 主线程封装
   * ================================================================== */
  const KERNEL_SRC = '(' + kernelBody.toString() + ')(self, true);'

  function canUseWorker() {
    try {
      return typeof Worker === 'function' &&
        typeof Blob === 'function' &&
        typeof URL !== 'undefined' && typeof URL.createObjectURL === 'function' &&
        typeof OffscreenCanvas === 'function'
    } catch (e) {
      return false
    }
  }

  /**
   * 流体背景。Worker 优先；起不来就退回主线程，功能不丢。
   * @param {HTMLCanvasElement} canvas 主线程侧的"呈现画布"，供玻璃渲染器上传
   */
  function FluidHost(canvas, options) {
    options = options || {}
    const present = canvas
    let worker = null
    let blobUrl = null
    let kernel = null
    let latest = null
    let error = null
    let mode = 'pending'
    let frameCb = options.onFrame || null

    const api = {
      canvas: present,
      lastError: null,
      currentPhoto: null,
      mode: function () { return mode },
      onFrame: function (cb) { frameCb = cb },
    }

    if (options.worker !== false && canUseWorker()) {
      try {
        blobUrl = URL.createObjectURL(new Blob([KERNEL_SRC], { type: 'text/javascript' }))
        worker = new Worker(blobUrl)

        // Worker 可能"构造成功却永远不响应"（file:// 下 opaque origin、
        // 某些 WebView、CSP 限制等）。那样会卡在假 worker 状态：
        // 消息发出去没人收，背景全空，且不回退。所以要求握手。
        let handedShake = false
        const handshake = setTimeout(function () {
          if (handedShake) return
          api.lastError = 'worker handshake timeout'
          fallbackToMain('worker handshake timeout')
        }, options.handshakeMs || 1500)

        worker.onmessage = function (e) {
          const m = e.data
          if (!m) return
          if (m.type === 'ready') {
            handedShake = true
            clearTimeout(handshake)
            mode = 'worker'
            return
          }
          if (m.type === 'error') {
            error = m.message
            api.lastError = m.message
            // 内核在 Worker 里起不来（比如没有 GL），退回主线程再试一次
            if (!handedShake) { clearTimeout(handshake); fallbackToMain(m.message) }
            return
          }
          if (m.type === 'frame') { receiveFrame(m); return }
          latest = Object.assign(latest || {}, m)
        }
        worker.onerror = function (e) {
          error = (e && e.message) || 'worker error'
          api.lastError = error
          if (!handedShake) { clearTimeout(handshake); fallbackToMain(error) }
        }
        // Worker 自己创建 OffscreenCanvas 渲染；DOM canvas 的控制权不转移，
        // 主线程始终把最新一帧画进它，供玻璃渲染器上传。
        worker.postMessage({
          type: 'attach', canvas: null,
          width: options.width || 1, height: options.height || 1,
          seed: options.seed || 1,
        })
        mode = 'worker'
      } catch (e) {
        fallbackToMain((e && e.message) || String(e))
      }
    } else {
      startMain()
    }

    /** 放弃 Worker，退回主线程内核。present canvas 的控制权从未转移，
     *  所以这里可以直接拿它建 GL 上下文。 */
    function fallbackToMain(reason) {
      if (mode === 'main' || mode === 'failed') return
      error = reason || error
      api.lastError = error
      if (worker) { try { worker.terminate() } catch (e) {} worker = null }
      if (blobUrl) { try { URL.revokeObjectURL(blobUrl) } catch (e) {} blobUrl = null }
      startMain()
    }

    function startMain() {
      try {
        (new Function('return ' + kernelBody.toString()))()(window, false)
        kernel = window.__fluidKernel.FluidBackground(present, {
          width: options.width || 1, height: options.height || 1, seed: options.seed || 1,
        })
        mode = 'main'
        // 握手失败回退时，之前 setPhoto 是发给 Worker 的（已被 terminate），
        // 新内核什么都没收到。这里补回去，否则照片/配色全丢。
        if (api.currentPhoto) {
          try {
            kernel.setPhoto(api.currentPhoto)
            kernel.settle(1400)
          } catch (e2) {}
        }
      } catch (e) {
        error = (e && e.message) || String(e)
        api.lastError = error
        kernel = null
        mode = 'failed'
      }
    }

    /** 收到 Worker 的一帧：画进呈现画布，再通知外部上传。 */
    function receiveFrame(m) {
      latest = Object.assign(latest || {}, {
        coverage: m.coverage, fade: m.fade, transition: m.transition,
        covered: m.covered, size: m.size, luma: m.luma,
        scale: m.scale, gpuMs: m.gpuMs, timer: m.timer,
      })
      const bmp = m.bitmap
      if (!bmp) return
      try {
        const g = present.getContext('2d')
        if (g && bmp.width && bmp.height) {
          if (present.width !== bmp.width) present.width = bmp.width
          if (present.height !== bmp.height) present.height = bmp.height
          g.drawImage(bmp, 0, 0)
        }
        if (typeof bmp.close === 'function') bmp.close()
      } catch (e) {
        api.lastError = 'draw frame: ' + ((e && e.message) || e)
      }
      if (frameCb) { try { frameCb() } catch (e) {} }
    }

    function post(msg) { if (worker) { try { worker.postMessage(msg) } catch (e) {} } }

    api.resize = function (w, h) {
      if (kernel) kernel.resize(w, h)
      else post({ type: 'resize', width: w, height: h })
    }
    api.start = function () {
      if (kernel) kernel.start()
      else post({ type: 'start' })
    }
    api.stop = function () {
      if (kernel) kernel.stop()
      else post({ type: 'stop' })
    }
    api.setPaused = function (v) {
      if (kernel) kernel.setPaused(v)
      else post({ type: 'paused', value: !!v })
    }
    api.setColors = function (list) {
      if (kernel) kernel.setColors(list)
      else post({ type: 'colors', colors: list })
    }
    api.setPhoto = function (bitmap) {
      api.currentPhoto = bitmap || null
      if (kernel) { kernel.setPhoto(bitmap); return }
      const send = function (bmp) {
        try { post({ type: 'photo', bitmap: bmp }) }
        catch (e) { api.lastError = 'photo: ' + ((e && e.message) || e) }
      }
      if (!bitmap) { send(null); return }
      if (typeof createImageBitmap === 'function' && typeof ImageBitmap === 'function' &&
          !(bitmap instanceof ImageBitmap)) {
        try {
          createImageBitmap(bitmap).then(function (b) {
            post({ type: 'photo', bitmap: b }, [b])
          }).catch(function () { send(bitmap) })
        } catch (e) { send(bitmap) }
      } else {
        send(bitmap)
      }
    }
    api.renderOnce = function () {
      if (kernel) kernel.renderOnce()
      else post({ type: 'renderOnce' })
    }
    api.settle = function (ms) {
      if (kernel) kernel.settle(ms)
      else post({ type: 'settle', ms: ms || 1400 })
    }
    api.requestFrame = function () {
      if (!worker) { if (kernel) kernel.renderOnce(); return }
      post({ type: 'frame' })
    }
    api.dispose = function () {
      if (kernel) { try { kernel.dispose() } catch (e) {} kernel = null }
      if (worker) { try { worker.terminate() } catch (e) {} worker = null }
      if (blobUrl) { try { URL.revokeObjectURL(blobUrl) } catch (e) {} blobUrl = null }
    }

    /**
     * 过渡状态。
     *
     * 绝不能返回 null：Worker 模式下首帧还没回来时 latest 为空，
     * 而调用方（app.js 的 ensureConverged）在启动最初几帧就会读它 ——
     * 返回 null 会直接抛 "Cannot read properties of null (reading 'covered')"
     * 把整个启动打断。没有真实数据时返回 known:false，让调用方跳过。
     */
    api.converge = function () {
      if (kernel) {
        const c = kernel.converge()
        return {
          coverage: c.coverage, fade: c.fade, transition: c.transition,
          covered: c.covered, known: true,
        }
      }
      if (!latest) {
        return { coverage: 0, fade: 0, transition: 0, covered: false, known: false }
      }
      return {
        coverage: latest.coverage != null ? latest.coverage : 0,
        fade: latest.fade != null ? latest.fade : 0,
        transition: latest.transition != null ? latest.transition : 0,
        covered: !!latest.covered,
        known: true,
      }
    }
    api.sampleLuma = function () {
      if (kernel) return kernel.sampleLuma()
      if (latest && typeof latest.luma === 'number') return latest.luma
      return -1
    }
    /**
     * 自检。主线程模式喂白图同步测；Worker 模式无法同步测，
     * 返回 -1 表示「未知」—— 调用方必须容忍未知，不能当成失败，
     * 否则会把好端端的 Worker 路径误杀。
     */
    api.probe = function () {
      if (!kernel) return -1
      try {
        let src = null
        if (typeof OffscreenCanvas === 'function') {
          const oc = new OffscreenCanvas(128, 128)
          const c = oc.getContext('2d')
          c.fillStyle = '#ffffff'
          c.fillRect(0, 0, 128, 128)
          src = oc
        } else if (typeof document !== 'undefined') {
          const cv = document.createElement('canvas')
          cv.width = cv.height = 128
          const c = cv.getContext('2d')
          c.fillStyle = '#ffffff'
          c.fillRect(0, 0, 128, 128)
          src = cv
        }
        if (!src) return -1
        const saved = api.currentPhoto
        kernel.setPhoto(src)
        kernel.settle(1400)
        const lum = kernel.sampleLuma()
        kernel.setPhoto(saved || null)
        kernel.settle(1400)
        return lum
      } catch (e) { return -1 }
    }
    api.diagnose = function () {
      const st = kernel && kernel.status ? kernel.status() : null
      const c = st || api.converge()
      return {
        luma: Math.round(api.sampleLuma() * 10) / 10,
        mode: mode,
        coverage: c ? Math.round(c.coverage * 1000) / 1000 : null,
        fade: c ? Math.round(c.fade * 1000) / 1000 : null,
        covered: c ? c.covered : null,
        hasTexture: st ? st.hasTexture : (latest ? latest.hasTexture : null),
        size: st ? st.size : (latest ? latest.size : [present.width, present.height]),
        scale: st ? st.scale : (latest ? latest.scale : null),
        gpuMs: st ? st.gpuMs : (latest ? latest.gpuMs : null),
        timer: st ? st.timer : (latest ? latest.timer : null),
        error: error || api.lastError || null,
      }
    }

    return api
  }

  FluidHost.supported = (function () {
    try {
      if (typeof OffscreenCanvas === 'function') return !!new OffscreenCanvas(1, 1).getContext('webgl2')
      const c = document.createElement('canvas')
      return !!c.getContext('webgl2')
    } catch (e) { return false }
  })()
  FluidHost.canUseWorker = canUseWorker

  window.FluidBackground = FluidHost
  window.__fluidKernelSrc = KERNEL_SRC
})()
