#!/usr/bin/env python3
"""从 bundle.py 生成的单文件 HTML 反向还原出完整源码工程。

为什么需要它：
  单文件版（odyssey-standalone.html）是唯一一个"放到哪都能活"的备份形态
  —— 邮件附件、网盘、备忘录都装得下。但如果只有它、源码目录没了，
  就得能把它变回可编辑的工程，否则后续没法继续迭代。

  有了 bundle.py → standalone.html → unbundle.py 这个闭环，
  备份才不只是"能跑"，而是"能继续改"。

做法：bundle.py 内联时给每个脚本块加了 `BUNDLE_FILE: xxx` 标记，
这里按标记把块拆出来，再重建 index.html 的外壳引用。

用法：  python3 unbundle.py <单文件.html> [输出目录]
"""
import os
import re
import sys

SRC_ORDER = ['app.js', 'motion.js', 'fluid.js', 'liquid-glass.js']

src = sys.argv[1] if len(sys.argv) > 1 else 'odyssey-standalone.html'
dest = sys.argv[2] if len(sys.argv) > 2 else './odyssey-restored'

if not os.path.exists(src):
    print('!! 找不到 ' + src)
    sys.exit(1)

html = open(src, encoding='utf-8').read()

# ---- 1) 按标记拆出各个源文件 ----
found = {}
for m in re.finditer(
        r'<script>\s*/\* ==== BUNDLE_FILE: ([\w.\-]+) ==== \*/\n(.*?)\n</script>',
        html, re.S):
    name, code = m.group(1), m.group(2)
    # bundle 时把 </script 转义成了 <\/script，这里还原
    found[name] = code.replace('<\\/script', '</script')

if not found:
    print('!! 这个 HTML 里没有 BUNDLE_FILE 标记，不是 bundle.py 生成的版本')
    sys.exit(1)

os.makedirs(dest, exist_ok=True)
for name in SRC_ORDER:
    if name not in found:
        print('!! 缺少 ' + name)
        sys.exit(1)
    p = os.path.join(dest, name)
    open(p, 'w', encoding='utf-8').write(found[name])
    print('  还原 %-18s %7d 字节' % (name, len(found[name])))

# ---- 2) 重建 index.html：内联块换回外链 ----
shell = html
for name in found:
    pat = (r'<script>\s*/\* ==== BUNDLE_FILE: ' + re.escape(name) +
           r' ==== \*/\n.*?\n</script>')
    shell = re.sub(pat, '<script src="' + name + '"></script>', shell, flags=re.S)

# 补回 manifest（bundle 时去掉了）
if 'rel="manifest"' not in shell:
    shell = shell.replace('<title>',
                          '<link rel="manifest" href="manifest.json" />\n<title>', 1)

# 补回 Service Worker 注册（bundle 时去掉了）
if 'serviceWorker' not in shell:
    anchor = 'if (document.readyState === \'complete\''
    inject = (
        "  // 离线缓存（file:// 下注册会失败，静默忽略）\n"
        "  if ('serviceWorker' in navigator && location.protocol !== 'file:') {\n"
        "    window.addEventListener('load', function () {\n"
        "      navigator.serviceWorker.register('sw.js').catch(function () {})\n"
        "    })\n"
        "  }\n\n")
    if anchor in shell:
        shell = shell.replace(anchor, inject + anchor, 1)

open(os.path.join(dest, 'index.html'), 'w', encoding='utf-8').write(shell)
print('  还原 %-18s %7d 字节' % ('index.html', len(shell)))

# ---- 3) 没有被内联的文件（icons / sw.js / manifest.json / android）----
#     这些不在单文件里，还原不了。从同目录拷贝，拷不到就明确告知。
here = os.path.dirname(os.path.abspath(__file__))
copied, missing = [], []
for item in ['manifest.json', 'sw.js', 'icons', 'android', 'tests',
             'bundle.py', 'unbundle.py', 'restore.sh', 'README.md', 'PUSH.md']:
    s = os.path.join(here, item)
    if not os.path.exists(s):
        missing.append(item)
        continue
    d = os.path.join(dest, item)
    if os.path.isdir(s):
        os.system('cp -r %s %s 2>/dev/null' % (repr(s), repr(d)))
    else:
        open(d, 'w', encoding='utf-8').write(open(s, encoding='utf-8').read())
    copied.append(item)

print()
print('==> 还原到 %s' % dest)
print('    从单文件解出：%s' % ', '.join(SRC_ORDER))
print('    从原目录补齐：%s' % (', '.join(copied) if copied else '无'))
if missing:
    print('    无法还原（不在这份备份里）：%s' % ', '.join(missing))
    print('    —— 这些不影响运行，缺 icons 只是没有桌面图标。')

# ---- 4) 自检：还原出来的 JS 必须能被解析 ----
print()
bad = 0
for name in SRC_ORDER:
    r = os.system('node --check %s 2>/dev/null' % repr(os.path.join(dest, name)))
    print('    语法 %-18s %s' % (name, 'OK' if r == 0 else '错误'))
    if r != 0:
        bad += 1
print('==> ' + ('还原完整，可直接运行' if bad == 0 else '有 %d 个文件语法损坏' % bad))
sys.exit(1 if bad else 0)
