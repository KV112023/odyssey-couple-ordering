# 上传到 GitHub

仓库目录已准备好：git 已初始化、已提交、`.gitignore` 已配好。
选一种方式推上去即可。

## 方式一：命令行（推荐）

先在 GitHub 上建一个**空仓库**（不要勾 README / .gitignore），
假设地址是 `https://github.com/YOUR_NAME/odyssey-table.git`：

```bash
cd repo
git remote add origin https://github.com/YOUR_NAME/odyssey-table.git
git branch -M main
git push -u origin main
```

用 Token 认证就把地址换成：

```
https://<TOKEN>@github.com/YOUR_NAME/odyssey-table.git
```

Token 需要 `repo` 权限。

## 方式二：网页上传

把 `repo/` 里的内容（除 `.git` 目录外）拖进新建仓库的
「Add file → Upload files」即可。

## 推上去之后

把 `restore.sh` 里的默认地址改成你自己的仓库，这样下次回档不用再填参数：

```bash
# 编辑 restore.sh 开头这一行
REPO="${1:-https://github.com/YOUR_NAME/odyssey-table.git}"
```

## 仓库里有什么

| 路径 | 说明 |
| --- | --- |
| `index.html` | 入口，双击即可运行 |
| `app.js` | 界面与交互 |
| `motion.js` | 缓动曲线 + 动态模糊 |
| `fluid.js` | 流体背景（WebGL2 Worker） |
| `liquid-glass.js` | 液态玻璃渲染器 |
| `manifest.json` / `sw.js` | PWA：装到桌面、断网可用 |
| `icons/` | 图标（含 maskable） |
| `android/` | APK 构建源码（smali + 签名脚本），`./build.sh` 可重建 |
| `restore.sh` | 回档脚本 |
| `tests/` 之外 | 本仓库只放运行时文件，测试脚本不在其中 |

## 关于隐私

菜单、点单记录、菜品图片都存在浏览器 localStorage 里，**不进代码仓库**。
仓库里只有默认菜单（6 道希腊主题菜），没有你们的真实数据。
