#!/usr/bin/env bash
# 从 smali 重新构建并签名 APK（需要 java + openssl + apktool.jar）
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
APKTOOL="${APKTOOL_JAR:-/usr/local/lib/node_modules/apktool/bin/apktool.jar}"
OUT="$(mktemp -d)"

mkdir -p "$OUT/smali"
cp -r "$HERE/smali/"* "$OUT/smali/"
mkdir -p "$OUT/assets"
cp "$HERE/../../odyssey/index.html" "$HERE/../../odyssey/app.js" \
   "$HERE/../../odyssey/fluid.js" "$HERE/../../odyssey/liquid-glass.js" \
   "$HERE/../../odyssey/manifest.json" "$HERE/../../odyssey/sw.js" \
   "$HERE/../../odyssey/README.md" "$OUT/assets/"
mkdir -p "$OUT/assets/icons"
cp "$HERE/../../odyssey/icons/"*.png "$OUT/assets/icons/"

# 1) smali -> classes.dex（apktool 内部汇编；aapt 缺失会报错，但 dex 已生成）
java -jar "$APKTOOL" b --force-all "$OUT" -o "$OUT/x.apk" || true
cp "$OUT/build/apk/classes.dex" "$HERE/classes.dex"

# 2) 生成二进制 AndroidManifest.xml + 打包 + v1 签名
python3 "$HERE/make_apk.py"
echo "done: $(dirname "$HERE")/odyssey.apk"
