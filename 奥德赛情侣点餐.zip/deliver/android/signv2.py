#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""APK Signature Scheme v2 —— 纯 Python 实现（RSA 运算交给 cryptography）。

Android 11 起，只签 v1（JAR）的 APK 会被拒绝安装，现象是 PackageInfo 为空 /
INSTALL_PARSE_FAILED_NO_CERTIFICATES。这里补上 v2 签名块。

布局参考 AOSP ApkSignatureSchemeV2Verifier：

  APK Signing Block 插在 Central Directory 之前：
    uint64  size-of-block（不含本字段）
    [uint64 size-of-pair][uint32 id=0x7109871a][value]   （可多组）
    uint64  size-of-block（与首个字段同值）
    16 字节 "APK Sig Block 42"

  EOCD 里的 "Central Directory offset" 改成 Signing Block 的起始位置。
"""
import hashlib
import struct

CHUNK = 1048576
V2_ID = 0x7109871A
MAGIC = b'APK Sig Block 42'
# RSASSA-PKCS1-v1_5 with SHA2-256，内容摘要算法 CHUNKED_SHA256
ALGO_RSA_PKCS1_SHA256 = 0x0103


def _lp(data):
    """uint32 长度前缀"""
    return struct.pack('<I', len(data)) + data


def _chunked_digest(data):
    """两级 Merkle：先对每 1MB 分片算摘要，再对摘要序列算顶层摘要。"""
    parts = []
    total = len(data)
    if total == 0:
        parts.append(hashlib.sha256(b'\xa5' + struct.pack('<I', 0)).digest())
    else:
        for i in range(0, total, CHUNK):
            c = data[i:i + CHUNK]
            parts.append(hashlib.sha256(b'\xa5' + struct.pack('<I', len(c)) + c).digest())
    return hashlib.sha256(
        b'\x5a' + struct.pack('<I', len(parts)) + b''.join(parts)
    ).digest()


def _find_eocd(apk):
    """定位 EOCD（末尾可能有注释，从后往前扫）"""
    n = len(apk)
    for pos in range(n - 22, max(-1, n - 22 - 65535), -1):
        if apk[pos:pos + 4] == b'PK\x05\x06':
            comment_len = struct.unpack('<H', apk[pos + 20:pos + 22])[0]
            if pos + 22 + comment_len == n:
                return pos
    raise ValueError('未找到 EOCD')


def sign_v2(apk_bytes, cert_der, key):
    """给一个已（或未）签名的 APK 加 v2 签名，返回新的 APK 字节。"""
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding

    eocd = _find_eocd(apk_bytes)
    cd_size = struct.unpack('<I', apk_bytes[eocd + 12:eocd + 16])[0]
    cd_offset = struct.unpack('<I', apk_bytes[eocd + 16:eocd + 20])[0]
    if cd_offset + cd_size > eocd:
        raise ValueError('Central Directory 范围异常')

    before = apk_bytes[:cd_offset]        # ZIP entries（local headers + data）
    central = apk_bytes[cd_offset:cd_offset + cd_size]
    eocd_bytes = bytearray(apk_bytes[eocd:])

    # 计算摘要时，EOCD 里的 CD offset 要替换成 Signing Block 的起始位置
    # （也就是当前 CD 的偏移），这样签名才覆盖"块被插入"这件事。
    struct.pack_into('<I', eocd_bytes, 16, cd_offset)

    digest1 = _chunked_digest(before)
    digest2 = _chunked_digest(central)
    digest3 = _chunked_digest(bytes(eocd_bytes))

    # ---- signed data ----
    # 序列里的每个元素也要自带 uint32 长度前缀
    digests = b''
    for d in (digest1, digest2, digest3):
        digests += _lp(struct.pack('<I', ALGO_RSA_PKCS1_SHA256) + _lp(d))
    certificates = _lp(cert_der)
    attributes = b''                      # 不需要额外属性
    signed_data = _lp(digests) + _lp(certificates) + _lp(attributes)

    # ---- 用私钥签 signed data ----
    signature = key.sign(signed_data, padding.PKCS1v15(), hashes.SHA256())

    public_key = key.public_key().public_bytes(
        serialization.Encoding.DER,
        serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    # ---- signer -> signers -> v2 block value ----
    signatures = _lp(struct.pack('<I', ALGO_RSA_PKCS1_SHA256) + _lp(signature))
    signer = _lp(signed_data) + _lp(signatures) + _lp(public_key)
    signers = _lp(signer)
    value = _lp(signers)

    pair = struct.pack('<Q', 4 + len(value)) + struct.pack('<I', V2_ID) + value
    # AOSP 定义：size 字段 = 整个块的大小，但不含「首个 size 字段本身」。
    # 也就是要把尾部的第二个 size(8) 和 magic(16) 一起算进去 —— 差这 24 字节
    # 会让 PackageParser 直接判定块非法（现象就是 PackageInfo 为空）。
    size = len(pair) + 24
    block = (struct.pack('<Q', size) + pair
             + struct.pack('<Q', size) + MAGIC)

    # ---- 组装：Signing Block 插到 CD 前，并修正 EOCD 的 CD offset ----
    out = bytearray()
    out += before
    out += block
    out += central
    final_eocd = bytearray(eocd_bytes)
    struct.pack_into('<I', final_eocd, 16, cd_offset + len(block))
    out += final_eocd
    return bytes(out)


def verify_layout(apk_bytes):
    """自检：Signing Block 存在、magic 正确、EOCD 的 CD offset 指向块之后。"""
    eocd = _find_eocd(apk_bytes)
    cd_offset = struct.unpack('<I', apk_bytes[eocd + 16:eocd + 20])[0]
    magic_pos = cd_offset - len(MAGIC)
    if magic_pos < 0 or apk_bytes[magic_pos:magic_pos + len(MAGIC)] != MAGIC:
        return False, 'magic 缺失'
    # 布局：[8B size][pair][8B size][16B magic]，块总长 = 8 + size
    size2 = struct.unpack('<Q', apk_bytes[magic_pos - 8:magic_pos])[0]
    block_start = magic_pos + 8 - size2
    size1 = struct.unpack('<Q', apk_bytes[block_start:block_start + 8])[0]
    if size1 != size2:
        return False, '块大小不一致'
    if block_start + 8 + size2 != cd_offset:
        return False, '块边界不对'
    # 找 v2 pair
    pos = block_start + 8
    end = magic_pos - 8
    found = False
    while pos + 12 <= end:
        plen = struct.unpack('<Q', apk_bytes[pos:pos + 8])[0]
        pid = struct.unpack('<I', apk_bytes[pos + 8:pos + 12])[0]
        if pid == V2_ID:
            found = True
            break
        pos += 8 + plen
    if not found:
        return False, '未找到 v2 签名 pair'
    return True, 'v2 signing block ok (%d bytes)' % (cd_offset - block_start)
