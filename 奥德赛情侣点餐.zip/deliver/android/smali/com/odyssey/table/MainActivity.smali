.class public Lcom/odyssey/table/MainActivity;
.super Landroid/app/Activity;

.field private web:Landroid/webkit/WebView;

# WebView 选图回调（<input type="file">）。由 MainActivity$1 写入，
# 在 onActivityResult 里消费。
.field private uploadCallback:Landroid/webkit/ValueCallback;

# REQUEST 常量只在 smali 里以内联常量使用，无需声明。

# ---------------------------------------------------------------- constructor
.method public constructor <init>()V
    .locals 0
    invoke-direct {p0}, Landroid/app/Activity;-><init>()V
    return-void
.end method

# ---------------------------------------------------------------- onCreate
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 4

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    # 全屏：FLAG_FULLSCREEN = 0x400
    invoke-virtual {p0}, Lcom/odyssey/table/MainActivity;->getWindow()Landroid/view/Window;
    move-result-object v0
    const/16 v1, 0x400
    invoke-virtual {v0, v1}, Landroid/view/Window;->addFlags(I)V

    # web = new WebView(this)
    new-instance v0, Landroid/webkit/WebView;
    invoke-direct {v0, p0}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V
    iput-object v0, p0, Lcom/odyssey/table/MainActivity;->web:Landroid/webkit/WebView;

    # web.setBackgroundColor(0xFF05080F)
    const v1, -0xfaf7f1
    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setBackgroundColor(I)V

    # setContentView(web)
    invoke-virtual {p0, v0}, Lcom/odyssey/table/MainActivity;->setContentView(Landroid/view/View;)V

    # s = web.getSettings()
    invoke-virtual {v0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setDatabaseEnabled(Z)V
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowFileAccessFromFileURLs(Z)V
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setAllowUniversalAccessFromFileURLs(Z)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setUseWideViewPort(Z)V
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setLoadWithOverviewMode(Z)V
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setSupportZoom(Z)V
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setBuiltInZoomControls(Z)V
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setDisplayZoomControls(Z)V
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setMediaPlaybackRequiresUserGesture(Z)V

    const/4 v1, 0x2
    invoke-virtual {v0, v1}, Landroid/webkit/WebSettings;->setCacheMode(I)V

    # web.setWebViewClient(new WebViewClient())
    iget-object v0, p0, Lcom/odyssey/table/MainActivity;->web:Landroid/webkit/WebView;
    new-instance v1, Landroid/webkit/WebViewClient;
    invoke-direct {v1}, Landroid/webkit/WebViewClient;-><init>()V
    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    # web.setWebChromeClient(new MainActivity$1(this))
    # 必须是自定义的：基类 WebChromeClient 不处理 onShowFileChooser，
    # 页面里的 <input type="file"> 会完全没有反应。
    new-instance v1, Lcom/odyssey/table/MainActivity$1;
    invoke-direct {v1, p0}, Lcom/odyssey/table/MainActivity$1;-><init>(Lcom/odyssey/table/MainActivity;)V
    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    # web.loadUrl("file:///android_asset/index.html")
    const-string v1, "file:///android_asset/index.html"
    invoke-virtual {v0, v1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method

# ---------------------------------------------------------------- onBackPressed
.method public onBackPressed()V
    .locals 1

    iget-object v0, p0, Lcom/odyssey/table/MainActivity;->web:Landroid/webkit/WebView;
    if-eqz v0, :cond_back

    invoke-virtual {v0}, Landroid/webkit/WebView;->canGoBack()Z
    move-result v0
    if-eqz v0, :cond_back

    iget-object v0, p0, Lcom/odyssey/table/MainActivity;->web:Landroid/webkit/WebView;
    invoke-virtual {v0}, Landroid/webkit/WebView;->goBack()V
    return-void

    :cond_back
    invoke-super {p0}, Landroid/app/Activity;->onBackPressed()V
    return-void
.end method

# ------------------------------------------- synthetic setter for uploadCallback
# dx 生成的 access$002：写字段并返回新值。内部类靠它把回调交给 Activity。
.method static synthetic access$002(Lcom/odyssey/table/MainActivity;Landroid/webkit/ValueCallback;)Landroid/webkit/ValueCallback;
    .locals 0

    iput-object p1, p0, Lcom/odyssey/table/MainActivity;->uploadCallback:Landroid/webkit/ValueCallback;

    return-object p1
.end method

# ---------------------------------------------------------------- onActivityResult
.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 5

    .param p1, "requestCode"    # I
    .param p2, "resultCode"     # I
    .param p3, "data"           # Landroid/content/Intent;

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(III)V

    # 只处理我们的选图请求（1001）
    const/16 v0, 0x3e9
    if-ne p1, v0, :cond_return

    iget-object v0, p0, Lcom/odyssey/table/MainActivity;->uploadCallback:Landroid/webkit/ValueCallback;

    if-eqz v0, :cond_return

    # v1 = 回传给 WebView 的结果；null 表示用户取消
    const/4 v1, 0x0

    # 只有 RESULT_OK(-1) 且 data 非空才真正取出 Uri
    const/4 v2, -0x1
    if-ne p2, v2, :cond_fill

    goto :cond_fire

    :cond_fill
    if-nez p3, :cond_fire

    invoke-virtual {p3}, Landroid/content/Intent;->getData()Landroid/net/Uri;
    move-result-object v2

    if-nez v2, :cond_fire

    # results = new Uri[]{ uri }
    const/4 v3, 0x1
    new-array v1, v3, [Landroid/net/Uri;
    const/4 v4, 0x0
    aput-object v2, v1, v4

    :cond_fire
    invoke-interface {v0, v1}, Landroid/webkit/ValueCallback;->onReceiveValue(Ljava/lang/Object;)V

    # 清掉回调，避免下次点击错配
    const/4 v1, 0x0
    iput-object v1, p0, Lcom/odyssey/table/MainActivity;->uploadCallback:Landroid/webkit/ValueCallback;

    :cond_return
    return-void
.end method

# ---------------------------------------------------------------- onPause
.method protected onPause()V
    .locals 1

    iget-object v0, p0, Lcom/odyssey/table/MainActivity;->web:Landroid/webkit/WebView;
    if-eqz v0, :cond_skip

    invoke-virtual {v0}, Landroid/webkit/WebView;->onPause()V

    :cond_skip
    invoke-super {p0}, Landroid/app/Activity;->onPause()V
    return-void
.end method

# ---------------------------------------------------------------- onResume
.method protected onResume()V
    .locals 1

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    iget-object v0, p0, Lcom/odyssey/table/MainActivity;->web:Landroid/webkit/WebView;
    if-eqz v0, :cond_skip

    invoke-virtual {v0}, Landroid/webkit/WebView;->onResume()V

    :cond_skip
    return-void
.end method

# ---------------------------------------------------------------- onDestroy
.method protected onDestroy()V
    .locals 2

    iget-object v0, p0, Lcom/odyssey/table/MainActivity;->web:Landroid/webkit/WebView;
    if-eqz v0, :cond_skip

    invoke-virtual {v0}, Landroid/webkit/WebView;->destroy()V
    const/4 v0, 0x0
    iput-object v0, p0, Lcom/odyssey/table/MainActivity;->web:Landroid/webkit/WebView;

    :cond_skip
    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V
    return-void
.end method
