.class Lcom/odyssey/table/MainActivity$1;
.super Landroid/webkit/WebChromeClient;

# 重写 onShowFileChooser，否则 WebView 里的 <input type="file"> 永远不会
# 弹出文件选择器（基类 WebChromeClient 默认返回 false）—— 在 APK 里表现
# 为「点了放照片，什么都没发生」。

.field final synthetic this$0:Lcom/odyssey/table/MainActivity;

.method constructor <init>(Lcom/odyssey/table/MainActivity;)V
    .locals 0

    iput-object p1, p0, Lcom/odyssey/table/MainActivity$1;->this$0:Lcom/odyssey/table/MainActivity;

    invoke-direct {p0}, Landroid/webkit/WebChromeClient;-><init>()V

    return-void
.end method

.method public onShowFileChooser(Landroid/webkit/WebView;Landroid/webkit/ValueCallback;Landroid/webkit/WebChromeClient$FileChooserParams;)Z
    .locals 5

    .param p1, "webView"    # Landroid/webkit/WebView;
    .param p2, "callback"   # Landroid/webkit/ValueCallback;
    .param p3, "params"     # Landroid/webkit/WebChromeClient$FileChooserParams;

    # v0 = 外部 Activity
    iget-object v0, p0, Lcom/odyssey/table/MainActivity$1;->this$0:Lcom/odyssey/table/MainActivity;

    # 先清掉上一次残留的回调，避免旧回调与新选择结果错配
    const/4 v1, 0x0
    invoke-static {v0, v1}, Lcom/odyssey/table/MainActivity;->access$002(Lcom/odyssey/table/MainActivity;Landroid/webkit/ValueCallback;)Landroid/webkit/ValueCallback;

    # 存下这次的回调
    invoke-static {v0, p2}, Lcom/odyssey/table/MainActivity;->access$002(Lcom/odyssey/table/MainActivity;Landroid/webkit/ValueCallback;)Landroid/webkit/ValueCallback;

    # --- 构造选择器 Intent ---
    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.GET_CONTENT"
    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v2, "android.intent.category.OPENABLE"
    invoke-virtual {v1, v2}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const-string v2, "image/*"
    invoke-virtual {v1, v2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    # REQUEST_CODE = 1001
    const/16 v3, 0x3e9

    :try_start_0
    invoke-virtual {v0, v1, v3}, Lcom/odyssey/table/MainActivity;->startActivityForResult(Landroid/content/Intent;I)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x1
    return v1

    :catch_0
    move-exception v4

    # 设备上没有任何可用的文件选择器：清回调并告诉 WebView 这次取消了，
    # 否则回调一直挂着，下次点击会错配。
    const/4 v1, 0x0
    invoke-static {v0, v1}, Lcom/odyssey/table/MainActivity;->access$002(Lcom/odyssey/table/MainActivity;Landroid/webkit/ValueCallback;)Landroid/webkit/ValueCallback;

    return v1
.end method
